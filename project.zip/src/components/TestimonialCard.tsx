import React from 'react';
import { Star } from 'lucide-react';

interface TestimonialCardProps {
  name: string;
  country: string;
  text: string;
  avatar: string;
  trek: string;
}

const TestimonialCard: React.FC<TestimonialCardProps> = ({ name, country, text, avatar, trek }) => {
  return (
    <div className="bg-white rounded-2xl p-8 border border-stone-100 shadow-sm hover:shadow-md transition-all duration-300">
      <div className="flex items-center gap-1 mb-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
        ))}
      </div>
      <p className="text-stone-600 text-sm leading-relaxed mb-6 italic">"{text}"</p>
      <div className="flex items-center gap-3">
        <img
          src={avatar}
          alt={name}
          width={44}
          height={44}
          className="w-11 h-11 rounded-full object-cover border-2 border-amber-100"
        />
        <div>
          <p className="font-semibold text-stone-900 text-sm">{name}</p>
          <p className="text-stone-400 text-xs">{country} · {trek}</p>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;