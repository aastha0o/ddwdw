import React from 'react';
import { Link } from 'react-router-dom';
import { Mountain, Instagram, Facebook, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-950 text-stone-400 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4 group">
              <Mountain className="w-6 h-6 text-amber-400" />
              <span className="font-serif text-lg font-semibold text-white">
                Himalayan Discovery
              </span>
            </Link>
            <p className="text-sm leading-relaxed mb-6">
              Premium trekking and cultural journeys across Nepal's most breathtaking landscapes since 2008.
            </p>
            <div className="flex items-center gap-3">
              {[
                { icon: Instagram, label: 'Instagram' },
                { icon: Facebook, label: 'Facebook' },
                { icon: Twitter, label: 'Twitter' },
                { icon: Youtube, label: 'YouTube' },
              ].map(({ icon: Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  className="w-9 h-9 flex items-center justify-center rounded-full border border-stone-700 text-stone-400 hover:border-amber-400 hover:text-amber-400 transition-all duration-200"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">Explore</h3>
            <ul className="space-y-3 text-sm">
              {[
                { label: 'Destinations', path: '/destinations' },
                { label: 'Trekking Packages', path: '/destinations' },
                { label: 'Cultural Tours', path: '/destinations' },
                { label: 'Adventure Sports', path: '/destinations' },
              ].map((item) => (
                <li key={item.label}>
                  <Link
                    to={item.path}
                    className="hover:text-amber-400 transition-colors duration-200"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">Company</h3>
            <ul className="space-y-3 text-sm">
              {[
                { label: 'About Us', path: '/about' },
                { label: 'Our Team', path: '/about' },
                { label: 'Contact', path: '/contact' },
                { label: 'Blog', path: '/about' },
              ].map((item) => (
                <li key={item.label}>
                  <Link
                    to={item.path}
                    className="hover:text-amber-400 transition-colors duration-200"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-5">Contact</h3>
            <ul className="space-y-4 text-sm">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                <span>Thamel, Kathmandu, Nepal</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <span>+977 1 4700 123</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span>hello@himalayandiscovery.com</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="border-t border-stone-800">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-stone-600">
          <span>© 2026 Himalayan Discovery. All rights reserved.</span>
          <div className="flex items-center gap-5">
            <a href="#" className="hover:text-stone-400 transition-colors duration-200">Privacy Policy</a>
            <a href="#" className="hover:text-stone-400 transition-colors duration-200">Terms of Service</a>
            <a href="#" className="hover:text-stone-400 transition-colors duration-200">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;