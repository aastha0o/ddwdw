import React from 'react';
import { motion } from 'framer-motion';
import { Users, MapPin, Star, Award } from 'lucide-react';

const stats = [
  { icon: Users, value: '12,000+', label: 'Happy Trekkers' },
  { icon: MapPin, value: '40+', label: 'Destinations' },
  { icon: Star, value: '4.9', label: 'Average Rating' },
  { icon: Award, value: '18 Yrs', label: 'Experience' },
];

const StatsBanner: React.FC = () => {
  return (
    <section className="bg-stone-950 py-14">
      <div className="max-w-7xl mx-auto px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="flex flex-col items-center text-center"
            >
              <stat.icon className="w-6 h-6 text-amber-400 mb-3" />
              <span className="font-serif text-3xl font-bold text-white mb-1">{stat.value}</span>
              <span className="text-stone-400 text-sm">{stat.label}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatsBanner;