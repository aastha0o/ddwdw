import React from 'react';
import { motion } from 'framer-motion';
import { Clock, TrendingUp, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export interface Destination {
  id: string;
  name: string;
  tagline: string;
  image: string;
  duration: string;
  difficulty: string;
  region: string;
}

interface DestinationCardProps {
  destination: Destination;
  index: number;
}

const DestinationCard: React.FC<DestinationCardProps> = ({ destination, index }) => {
  return (
    <motion.article
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group bg-white rounded-2xl overflow-hidden border border-stone-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
    >
      <div className="relative overflow-hidden h-52">
        <img
          src={destination.image}
          alt={destination.name}
          width={480}
          height={208}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-stone-900/60 via-transparent to-transparent" />
        <span className="absolute top-4 left-4 px-3 py-1 bg-amber-500 text-stone-950 text-xs font-semibold rounded-full">
          {destination.region}
        </span>
      </div>
      <div className="p-6">
        <h3 className="font-serif text-xl font-semibold text-stone-900 mb-1">{destination.name}</h3>
        <p className="text-stone-500 text-sm mb-4 leading-relaxed">{destination.tagline}</p>
        <div className="flex items-center gap-4 text-xs text-stone-400 mb-5">
          <span className="flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            {destination.duration}
          </span>
          <span className="flex items-center gap-1.5">
            <TrendingUp className="w-3.5 h-3.5" />
            {destination.difficulty}
          </span>
        </div>
        <Link
          to="/contact"
          className="inline-flex items-center gap-2 text-sm font-semibold text-amber-600 hover:text-amber-500 transition-colors duration-200 group/link"
        >
          Book This Trek
          <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform duration-200" />
        </Link>
      </div>
    </motion.article>
  );
};

export default DestinationCard;