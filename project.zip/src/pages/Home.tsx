import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, ChevronDown, Shield, Compass, Heart } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import StatsBanner from '../components/StatsBanner';
import DestinationCard from '../components/DestinationCard';
import TestimonialCard from '../components/TestimonialCard';
import type { Destination } from '../components/DestinationCard';

const featuredDestinations: Destination[] = [
  {
    id: 'ebc',
    name: 'Everest Base Camp',
    tagline: "Stand at the foot of the world's highest peak on this legendary 14-day trek.",
    image: 'https://images.unsplash.com/photo-1516912481808-3406841bd33c?w=800&q=80',
    duration: '14 Days',
    difficulty: 'Challenging',
    region: 'Khumbu',
  },
  {
    id: 'annapurna',
    name: 'Annapurna Circuit',
    tagline: 'A classic high-altitude loop through diverse landscapes and ancient villages.',
    image: 'https://images.unsplash.com/photo-1585409677983-0f6c41ca9c3b?w=800&q=80',
    duration: '18 Days',
    difficulty: 'Moderate',
    region: 'Annapurna',
  },
  {
    id: 'langtang',
    name: 'Langtang Valley',
    tagline: 'Glaciers, yak pastures, and Tamang culture in the valley closest to Kathmandu.',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80',
    duration: '10 Days',
    difficulty: 'Moderate',
    region: 'Langtang',
  },
];

const testimonials = [
  {
    name: 'Sarah Mitchell',
    country: 'United Kingdom',
    text: 'The Everest Base Camp trek with Himalayan Discovery was the most transformative experience of my life. Our guide Pemba was exceptional — knowledgeable, caring, and incredibly skilled.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80',
    trek: 'Everest Base Camp',
  },
  {
    name: 'Marco Bianchi',
    country: 'Italy',
    text: 'From logistics to the mountain itself, everything was flawless. The Annapurna Circuit exceeded every expectation. I will absolutely return for another adventure.',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80',
    trek: 'Annapurna Circuit',
  },
  {
    name: 'Yuki Tanaka',
    country: 'Japan',
    text: 'Langtang Valley was breathtaking and the cultural immersion was something I never expected. The team made me feel safe and welcomed throughout the entire journey.',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&q=80',
    trek: 'Langtang Valley',
  },
];

const whyUs = [
  {
    icon: Shield,
    title: 'Safety First',
    desc: 'All guides are certified wilderness first responders. We carry satellite communication and full medical kits on every trek.',
  },
  {
    icon: Compass,
    title: 'Expert Local Guides',
    desc: 'Our guides are born in the Himalayas. Their knowledge of terrain, culture, and altitude is unmatched.',
  },
  {
    icon: Heart,
    title: 'Responsible Tourism',
    desc: 'We operate with a strict leave-no-trace policy and contribute 5% of revenue to local community development.',
  },
];

const Home: React.FC = () => {
  return (
    <div className="min-h-screen bg-stone-50">
      <Header />

      {/* Hero */}
      <section
        id="home"
        className="relative h-screen flex items-center justify-center text-center overflow-hidden"
        aria-label="Hero section"
      >
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1800&q=85"
            alt="Dramatic Himalayan mountain peaks at sunrise with snow-capped summits"
            width={1800}
            height={1080}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-stone-950/50 via-stone-950/30 to-stone-950/70" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-6">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-amber-400 text-sm font-semibold uppercase tracking-[0.2em] mb-5"
          >
            Nepal's Premier Trekking Company
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-serif text-5xl md:text-7xl font-bold text-white leading-tight mb-6"
          >
            Explore the
            <br />
            <span className="text-amber-400">Himalayas</span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-stone-200 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Adventure, peace, and unforgettable journeys through the world's most magnificent mountain landscapes.
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link
              to="/destinations"
              className="inline-flex items-center gap-2 px-8 py-4 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded-full transition-all duration-200 hover:scale-105 text-base"
            >
              View Destinations
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              to="/about"
              className="inline-flex items-center gap-2 px-8 py-4 border border-white/40 hover:border-white text-white font-semibold rounded-full transition-all duration-200 hover:bg-white/10 text-base"
            >
              Our Story
            </Link>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.6 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/60"
          aria-hidden="true"
        >
          <ChevronDown className="w-6 h-6 animate-bounce" />
        </motion.div>
      </section>

      {/* Stats */}
      <StatsBanner />

      {/* Featured Destinations */}
      <section className="py-24 px-6 lg:px-8 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <p className="text-amber-600 text-sm font-semibold uppercase tracking-widest mb-3">
            Handpicked Routes
          </p>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-stone-900 mb-4">
            Top Destinations
          </h2>
          <p className="text-stone-500 max-w-xl mx-auto text-base leading-relaxed">
            From the iconic Everest Base Camp to hidden valleys, every route is curated for an extraordinary experience.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {featuredDestinations.map((dest, i) => (
            <DestinationCard key={dest.id} destination={dest} index={i} />
          ))}
        </div>

        <div className="text-center">
          <Link
            to="/destinations"
            className="inline-flex items-center gap-2 px-7 py-3.5 border-2 border-stone-900 text-stone-900 hover:bg-stone-900 hover:text-white font-semibold rounded-full transition-all duration-200 hover:scale-105"
          >
            View All Destinations
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Why Us */}
      <section className="bg-amber-50 py-24 border-y border-amber-100">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-14"
          >
            <p className="text-amber-600 text-sm font-semibold uppercase tracking-widest mb-3">
              Why Choose Us
            </p>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-stone-900">
              The Himalayan Discovery Difference
            </h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {whyUs.map((item, i) => (
              <motion.div
                key={item.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.12 }}
                className="bg-white rounded-2xl p-8 border border-amber-100 shadow-sm hover:shadow-md transition-all duration-300"
              >
                <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center mb-5">
                  <item.icon className="w-6 h-6 text-amber-600" />
                </div>
                <h3 className="font-serif text-xl font-semibold text-stone-900 mb-3">{item.title}</h3>
                <p className="text-stone-500 text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Scenic Banner */}
      <section className="relative h-96 overflow-hidden">
        <img
          src="https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=1800&q=80"
          alt="Trekkers walking along a high-altitude Himalayan trail with mountain panorama"
          width={1800}
          height={384}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-stone-950/55 flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="text-center px-6"
          >
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-white mb-5">
              Your Journey Begins Here
            </h2>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded-full transition-all duration-200 hover:scale-105"
            >
              Plan My Trek
              <ArrowRight className="w-5 h-5" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-6 lg:px-8 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <p className="text-amber-600 text-sm font-semibold uppercase tracking-widest mb-3">
            Traveller Stories
          </p>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-stone-900">
            What Our Trekkers Say
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.12 }}
            >
              <TestimonialCard {...t} />
            </motion.div>
          ))}
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;