import React from 'react';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'react-toastify';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const schema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email address'),
  trek: z.string().min(1, 'Please select a trek of interest'),
  message: z.string().min(10, 'Message must be at least 10 characters'),
});

type FormData = z.infer<typeof schema>;

const contactInfo = [
  {
    icon: MapPin,
    label: 'Address',
    value: 'Thamel, Kathmandu, Nepal',
  },
  {
    icon: Phone,
    label: 'Phone',
    value: '+977 1 4700 123',
  },
  {
    icon: Mail,
    label: 'Email',
    value: 'hello@himalayandiscovery.com',
  },
  {
    icon: Clock,
    label: 'Office Hours',
    value: 'Mon–Sat, 8:00 AM – 6:00 PM NPT',
  },
];

const treks = [
  'Everest Base Camp',
  'Annapurna Circuit',
  'Annapurna Base Camp',
  'Langtang Valley',
  'Upper Mustang',
  'Manaslu Circuit',
  'Gokyo Lakes',
  'Pokhara & Phewa Lake',
  'Lumbini Pilgrimage',
  'Custom Itinerary',
];

const Contact: React.FC = () => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  const onSubmit = async (data: FormData) => {
    await new Promise((r) => setTimeout(r, 800));
    toast.success(`Thank you, ${data.name}! We'll be in touch within 24 hours.`);
    reset();
  };

  return (
    <div className="min-h-screen bg-stone-50">
      <Header />

      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=1800&q=80"
            alt="Misty Himalayan valley at dawn with prayer flags in the foreground"
            width={1800}
            height={400}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-stone-950/65" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-serif text-5xl md:text-6xl font-bold text-white mb-5"
          >
            Plan Your Trek
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="text-stone-300 text-lg max-w-xl mx-auto leading-relaxed"
          >
            Tell us about your dream adventure and our team will craft a personalised itinerary within 24 hours.
          </motion.p>
        </div>
      </section>

      {/* Content */}
      <section className="py-24 px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
          {/* Info */}
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-2 space-y-6"
          >
            <div>
              <p className="text-amber-600 text-sm font-semibold uppercase tracking-widest mb-3">Get In Touch</p>
              <h2 className="font-serif text-3xl font-bold text-stone-900 mb-4">We're here to help</h2>
              <p className="text-stone-500 text-sm leading-relaxed">
                Whether you're a first-time trekker or a seasoned mountaineer, our team is ready to answer every question and build the perfect Himalayan experience for you.
              </p>
            </div>

            <div className="space-y-5">
              {contactInfo.map((item) => (
                <div key={item.label} className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center shrink-0">
                    <item.icon className="w-5 h-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-stone-400 uppercase tracking-wider mb-0.5">{item.label}</p>
                    <p className="text-stone-700 text-sm font-medium">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl overflow-hidden border border-stone-200 shadow-sm h-52">
              <img
                src="https://images.unsplash.com/photo-1605640840605-14ac1855827b?w=600&q=80"
                alt="Kathmandu Thamel district street view with traditional architecture"
                width={600}
                height={208}
                className="w-full h-full object-cover"
              />
            </div>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-3"
          >
            <div className="bg-white rounded-2xl border border-stone-100 shadow-sm p-8 md:p-10">
              <h2 className="font-serif text-2xl font-bold text-stone-900 mb-8">Send Us a Message</h2>
              <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-semibold text-stone-700 mb-2">
                      Full Name
                    </label>
                    <input
                      id="name"
                      type="text"
                      placeholder="Jane Smith"
                      {...register('name')}
                      className="w-full px-4 py-3 rounded-lg border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 text-stone-900 placeholder-stone-400 text-sm transition-all duration-200"
                    />
                    {errors.name && (
                      <p className="mt-1.5 text-xs text-red-500">{errors.name.message}</p>
                    )}
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-semibold text-stone-700 mb-2">
                      Email Address
                    </label>
                    <input
                      id="email"
                      type="email"
                      placeholder="jane@example.com"
                      {...register('email')}
                      className="w-full px-4 py-3 rounded-lg border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 text-stone-900 placeholder-stone-400 text-sm transition-all duration-200"
                    />
                    {errors.email && (
                      <p className="mt-1.5 text-xs text-red-500">{errors.email.message}</p>
                    )}
                  </div>
                </div>

                <div>
                  <label htmlFor="trek" className="block text-sm font-semibold text-stone-700 mb-2">
                    Trek of Interest
                  </label>
                  <select
                    id="trek"
                    {...register('trek')}
                    className="w-full px-4 py-3 rounded-lg border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 text-stone-900 text-sm transition-all duration-200 bg-white"
                  >
                    <option value="">Select a destination…</option>
                    {treks.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                  {errors.trek && (
                    <p className="mt-1.5 text-xs text-red-500">{errors.trek.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-stone-700 mb-2">
                    Your Message
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    placeholder="Tell us about your group size, preferred dates, fitness level, or any questions…"
                    {...register('message')}
                    className="w-full px-4 py-3 rounded-lg border border-stone-200 focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 text-stone-900 placeholder-stone-400 text-sm transition-all duration-200 resize-none"
                  />
                  {errors.message && (
                    <p className="mt-1.5 text-xs text-red-500">{errors.message.message}</p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full inline-flex items-center justify-center gap-2 px-8 py-4 bg-amber-500 hover:bg-amber-400 disabled:opacity-60 disabled:cursor-not-allowed text-stone-950 font-semibold rounded-full transition-all duration-200 hover:scale-105 text-base"
                >
                  {isSubmitting ? 'Sending…' : 'Send Message'}
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;