import React from 'react';
import { Link } from 'react-router-dom';
import { Mountain, ArrowLeft } from 'lucide-react';

const NotFound: React.FC = () => {
  return (
    <div className="min-h-screen bg-stone-950 flex items-center justify-center px-6">
      <div className="text-center max-w-md">
        <Mountain className="w-16 h-16 text-amber-400 mx-auto mb-6" />
        <h1 className="font-serif text-6xl font-bold text-white mb-4">404</h1>
        <p className="text-stone-400 text-lg mb-8 leading-relaxed">
          This trail doesn't exist. The path you're looking for may have moved or never existed.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-7 py-3.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold rounded-full transition-all duration-200 hover:scale-105"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Base Camp
        </Link>
      </div>
    </div>
  );
};

export default NotFound;