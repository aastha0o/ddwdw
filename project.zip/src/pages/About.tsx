import React from 'react';
import { motion } from 'framer-motion';
import { Mountain, Leaf, Users, Globe } from 'lucide-react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import StatsBanner from '../components/StatsBanner';

const team = [
  {
    name: 'Pemba Sherpa',
    role: 'Head Guide & Co-Founder',
    bio: 'Born in Namche Bazaar, Pemba has summited Everest seven times and guided over 400 trekkers to Base Camp.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&q=80',
  },
  {
    name: 'Aarati Thapa',
    role: 'Operations Director',
    bio: 'With a background in sustainable tourism, Aarati ensures every expedition runs smoothly and responsibly.',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&q=80',
  },
  {
    name: 'Rajesh Gurung',
    role: 'Senior Trek Leader',
    bio: 'A certified wilderness first responder and cultural expert, Rajesh specialises in the Annapurna and Mustang regions.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&q=80',
  },
];

const values = [
  {
    icon: Mountain,
    title: 'Authentic Adventure',
    desc: 'We design routes that go beyond tourist trails, connecting you with the raw, unfiltered Himalayas.',
  },
  {
    icon: Leaf,
    title: 'Environmental Stewardship',
    desc: 'Leave-no-trace principles, carbon offset programs, and partnerships with local conservation groups.',
  },
  {
    icon: Users,
    title: 'Community First',
    desc: 'We employ local guides, porters, and lodge owners — ensuring tourism benefits the communities we visit.',
  },
  {
    icon: Globe,
    title: 'Global Standards',
    desc: 'TAAN and NMA certified. We meet international safety and quality benchmarks on every expedition.',
  },
];

const About: React.FC = () => {
  return (
    <div className="min-h-screen bg-stone-50">
      <Header />

      {/* Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1486870591958-9b9d0d1dda99?w=1800&q=80"
            alt="Himalayan mountain range at golden hour with dramatic cloud formations"
            width={1800}
            height={400}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-stone-950/60" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-serif text-5xl md:text-6xl font-bold text-white mb-5"
          >
            About Us
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="text-stone-300 text-lg max-w-2xl mx-auto leading-relaxed"
          >
            Born in the mountains. Built on trust. Driven by a love for Nepal.
          </motion.p>
        </div>
      </section>

      {/* Story */}
      <section className="py-24 px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <p className="text-amber-600 text-sm font-semibold uppercase tracking-widest mb-4">Our Story</p>
            <h2 className="font-serif text-4xl font-bold text-stone-900 mb-6 leading-tight">
              Two decades of Himalayan expertise
            </h2>
            <div className="space-y-4 text-stone-600 leading-relaxed">
              <p>
                Himalayan Discovery was founded in 2008 by Pemba Sherpa and a small team of passionate mountain guides who believed that trekking in Nepal could be done better — safer, more sustainably, and with deeper cultural connection.
              </p>
              <p>
                What began as a small operation in Thamel has grown into one of Nepal's most trusted trekking companies, having guided over 12,000 travellers from 80+ countries across the world's greatest mountain range.
              </p>
              <p>
                We remain proudly independent, locally owned, and committed to the values that started it all: authentic adventure, responsible tourism, and the belief that the mountains change people for the better.
              </p>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <img
              src="https://images.unsplash.com/photo-1551632811-561732d1e306?w=800&q=80"
              alt="Trekking guide leading a group through a high mountain pass"
              width={800}
              height={560}
              className="w-full h-96 object-cover rounded-2xl shadow-lg"
            />
            <div className="absolute -bottom-6 -left-6 bg-amber-500 rounded-2xl p-6 shadow-xl">
              <p className="font-serif text-3xl font-bold text-stone-950">18+</p>
              <p className="text-stone-800 text-sm font-medium">Years in the mountains</p>
            </div>
          </motion.div>
        </div>
      </section>

      <StatsBanner />

      {/* Values */}
      <section className="py-24 px-6 lg:px-8 max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <p className="text-amber-600 text-sm font-semibold uppercase tracking-widest mb-3">What We Stand For</p>
          <h2 className="font-serif text-4xl md:text-5xl font-bold text-stone-900">Our Values</h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {values.map((v, i) => (
            <motion.div
              key={v.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="flex gap-5 bg-white rounded-2xl p-8 border border-stone-100 shadow-sm hover:shadow-md transition-all duration-300"
            >
              <div className="w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center shrink-0">
                <v.icon className="w-6 h-6 text-amber-600" />
              </div>
              <div>
                <h3 className="font-serif text-xl font-semibold text-stone-900 mb-2">{v.title}</h3>
                <p className="text-stone-500 text-sm leading-relaxed">{v.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Team */}
      <section className="bg-stone-100 py-24 border-y border-stone-200">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-14"
          >
            <p className="text-amber-600 text-sm font-semibold uppercase tracking-widest mb-3">The People</p>
            <h2 className="font-serif text-4xl md:text-5xl font-bold text-stone-900">Meet Our Team</h2>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, i) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.12 }}
                className="bg-white rounded-2xl overflow-hidden border border-stone-100 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
              >
                <img
                  src={member.image}
                  alt={member.name}
                  width={400}
                  height={280}
                  className="w-full h-64 object-cover object-top"
                />
                <div className="p-6">
                  <h3 className="font-serif text-xl font-semibold text-stone-900 mb-1">{member.name}</h3>
                  <p className="text-amber-600 text-sm font-medium mb-3">{member.role}</p>
                  <p className="text-stone-500 text-sm leading-relaxed">{member.bio}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;