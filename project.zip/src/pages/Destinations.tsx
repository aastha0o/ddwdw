import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Header from '../components/Header';
import Footer from '../components/Footer';
import DestinationCard from '../components/DestinationCard';
import type { Destination } from '../components/DestinationCard';

const allDestinations: Destination[] = [
  {
    id: 'ebc',
    name: 'Everest Base Camp',
    tagline: "Stand at the foot of the world's highest peak on this legendary 14-day trek.",
    image: 'https://images.unsplash.com/photo-1516912481808-3406841bd33c?w=800&q=80',
    duration: '14 Days',
    difficulty: 'Challenging',
    region: 'Khumbu',
  },
  {
    id: 'annapurna',
    name: 'Annapurna Circuit',
    tagline: 'A classic high-altitude loop through diverse landscapes and ancient villages.',
    image: 'https://images.unsplash.com/photo-1585409677983-0f6c41ca9c3b?w=800&q=80',
    duration: '18 Days',
    difficulty: 'Moderate',
    region: 'Annapurna',
  },
  {
    id: 'langtang',
    name: 'Langtang Valley',
    tagline: 'Glaciers, yak pastures, and Tamang culture in the valley closest to Kathmandu.',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&q=80',
    duration: '10 Days',
    difficulty: 'Moderate',
    region: 'Langtang',
  },
  {
    id: 'mustang',
    name: 'Upper Mustang',
    tagline: 'Journey into the ancient Tibetan kingdom hidden behind the Annapurna massif.',
    image: 'https://images.unsplash.com/photo-1470770841072-f978cf4d019e?w=800&q=80',
    duration: '16 Days',
    difficulty: 'Moderate',
    region: 'Mustang',
  },
  {
    id: 'pokhara',
    name: 'Pokhara & Phewa Lake',
    tagline: 'Serene lakeside city with panoramic Annapurna views and adventure activities.',
    image: 'https://images.unsplash.com/photo-1571401835393-8c5f35328320?w=800&q=80',
    duration: '5 Days',
    difficulty: 'Easy',
    region: 'Gandaki',
  },
  {
    id: 'lumbini',
    name: 'Lumbini Pilgrimage',
    tagline: "Walk the sacred grounds of Lord Buddha's birthplace in the Terai lowlands.",
    image: 'https://images.unsplash.com/photo-1548013146-72479768bada?w=800&q=80',
    duration: '3 Days',
    difficulty: 'Easy',
    region: 'Lumbini',
  },
  {
    id: 'manaslu',
    name: 'Manaslu Circuit',
    tagline: "Nepal's most remote and dramatic circuit trek around the world's eighth-highest peak.",
    image: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&q=80',
    duration: '16 Days',
    difficulty: 'Challenging',
    region: 'Manaslu',
  },
  {
    id: 'gokyo',
    name: 'Gokyo Lakes',
    tagline: 'Turquoise glacial lakes and panoramic views from Gokyo Ri at 5,357m.',
    image: 'https://images.unsplash.com/photo-1501854140801-50d01698950b?w=800&q=80',
    duration: '12 Days',
    difficulty: 'Challenging',
    region: 'Khumbu',
  },
  {
    id: 'abc',
    name: 'Annapurna Base Camp',
    tagline: 'Trek into the heart of the Annapurna Sanctuary surrounded by 7,000m peaks.',
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=800&q=80',
    duration: '11 Days',
    difficulty: 'Moderate',
    region: 'Annapurna',
  },
];

const difficulties = ['All', 'Easy', 'Moderate', 'Challenging'];

const Destinations: React.FC = () => {
  const [filter, setFilter] = useState('All');

  const filtered = filter === 'All'
    ? allDestinations
    : allDestinations.filter((d) => d.difficulty === filter);

  return (
    <div className="min-h-screen bg-stone-50">
      <Header />

      {/* Page Hero */}
      <section className="relative pt-32 pb-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?w=1800&q=80"
            alt="Aerial view of Himalayan mountain range with snow-covered peaks"
            width={1800}
            height={400}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-stone-950/65" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="text-amber-400 text-sm font-semibold uppercase tracking-widest mb-4"
          >
            Explore Nepal
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-serif text-5xl md:text-6xl font-bold text-white mb-5"
          >
            All Destinations
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-stone-300 text-lg max-w-2xl mx-auto leading-relaxed"
          >
            From gentle cultural walks to high-altitude expeditions — find the trek that calls to you.
          </motion.p>
        </div>
      </section>

      {/* Filter */}
      <section className="py-10 px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center gap-3 justify-center">
          {difficulties.map((d) => (
            <button
              key={d}
              onClick={() => setFilter(d)}
              className={`px-5 py-2.5 rounded-full text-sm font-semibold border transition-all duration-200 ${
                filter === d
                  ? 'bg-stone-900 text-white border-stone-900'
                  : 'bg-white text-stone-600 border-stone-200 hover:border-stone-400 hover:text-stone-900'
              }`}
            >
              {d}
            </button>
          ))}
        </div>
      </section>

      {/* Grid */}
      <section className="pb-24 px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map((dest, i) => (
            <DestinationCard key={dest.id} destination={dest} index={i} />
          ))}
        </div>
        {filtered.length === 0 && (
          <div className="text-center py-20 text-stone-400">
            <p className="text-lg">No destinations match this filter.</p>
          </div>
        )}
      </section>

      <Footer />
    </div>
  );
};

export default Destinations;