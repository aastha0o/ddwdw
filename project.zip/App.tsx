import React, { Suspense, lazy } from 'react';
import '@radix-ui/themes/styles.css';
import { Theme } from '@radix-ui/themes';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './styles.css';

const Home = lazy(() => import('./src/pages/Home'));
const Destinations = lazy(() => import('./src/pages/Destinations'));
const About = lazy(() => import('./src/pages/About'));
const Contact = lazy(() => import('./src/pages/Contact'));
const NotFound = lazy(() => import('./src/pages/NotFound'));

const App: React.FC = () => {
  return (
    <Theme appearance="inherit" radius="large" scaling="100%">
      <Router>
        <Suspense
          fallback={
            <div className="min-h-screen bg-stone-950 flex items-center justify-center">
              <div className="w-8 h-8 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
            </div>
          }
        >
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/destinations" element={<Destinations />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
        <ToastContainer
          position="top-right"
          autoClose={4000}
          newestOnTop
          closeOnClick
          pauseOnHover
          toastClassName="font-sans text-sm"
        />
      </Router>
    </Theme>
  );
};

export default App;